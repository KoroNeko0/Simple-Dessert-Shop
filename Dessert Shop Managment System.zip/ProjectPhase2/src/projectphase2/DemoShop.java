
package projectphase2;

import java.util.*;

public class DemoShop {
    
    static Scanner in = new Scanner(System.in);
    
    public static void main(String[] args) {
                
        
            Frame1 starterFrame = new Frame1();
            starterFrame.setVisible(true);
        
               
    }//end main
    
}//end class
